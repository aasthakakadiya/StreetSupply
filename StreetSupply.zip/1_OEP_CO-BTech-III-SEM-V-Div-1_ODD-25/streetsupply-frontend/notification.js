document.addEventListener("DOMContentLoaded", async () => {
  const email = sessionStorage.getItem("email");

  if (!email) {
    alert("Please log in first.");
    window.location.href = "index.html";
    return;
  }

  const res = await fetch("http://localhost:3000/getNotifications", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });

  const notifications = await res.json();
  const container = document.getElementById("notificationsList");

  if (notifications.length === 0) {
    container.innerHTML = `
      <div class="no-notifications">
        <p>No notifications yet</p>
        <p>Start interacting with posts and users to receive notifications!</p>
      </div>
    `;
    return;
  }

  // Sort notifications by date (newest first)
  notifications.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  notifications.forEach(note => {
    const div = document.createElement("div");
    div.className = `notification ${!note.read ? "unread" : ""}`;
    
    // Get notification icon based on type
    const getNotificationIcon = (type) => {
      switch (type) {
        case 'like': return '👍';
        case 'comment': return '💬';
        case 'order': return '🛒';
        case 'connection': return '🤝';
        case 'share': return '📤';
        default: return '🔔';
      }
    };

    // Get notification color based on type
    const getNotificationColor = (type) => {
      switch (type) {
        case 'like': return '#ff6b6b';
        case 'comment': return '#4ecdc4';
        case 'order': return '#45b7d1';
        case 'connection': return '#96ceb4';
        case 'share': return '#feca57';
        default: return '#6c5ce7';
      }
    };

    const icon = getNotificationIcon(note.type);
    const color = getNotificationColor(note.type);

    div.innerHTML = `
      <div class="notification-content">
        <div class="notification-icon" style="background-color: ${color}">${icon}</div>
        <div class="notification-details">
          <p class="notification-message">${note.message || getDefaultMessage(note.type, note.sender)}</p>
          <small class="notification-time">${new Date(note.createdAt).toLocaleString()}</small>
          ${note.type === 'order' ? `<small class="order-id">Order ID: ${note.orderId || 'N/A'}</small>` : ''}
        </div>
        ${!note.read ? '<div class="unread-indicator"></div>' : ''}
      </div>
      <div class="notification-actions">
        ${note.type === 'connection' ? `
          <button class="accept-btn" onclick="acceptConnection('${note.sender}')">Accept</button>
          <button class="decline-btn" onclick="declineConnection('${note.sender}')">Decline</button>
        ` : ''}
        ${note.type === 'order' ? `
          <button class="view-order-btn" onclick="viewOrder('${note.orderId}')">View Order</button>
        ` : ''}
        <button class="mark-read-btn" onclick="markAsRead('${note._id}')">${note.read ? 'Mark Unread' : 'Mark Read'}</button>
      </div>
    `;

    div.addEventListener("click", async (e) => {
      // Don't trigger if clicking on action buttons
      if (e.target.tagName === 'BUTTON') return;

      // Mark as read
      if (!note.read) {
        await markAsRead(note._id);
      }

      // Navigate to relevant page based on notification type
      if (note.postId) {
        // For now, just show an alert. In a real app, you'd navigate to the post
        alert(`Navigate to post: ${note.postId}`);
      }
    });

    container.appendChild(div);
  });

  // Global functions for notification actions
  window.markAsRead = async function(notificationId) {
    try {
      const response = await fetch("http://localhost:3000/markNotificationRead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: notificationId }),
      });

      if (response.ok) {
        // Reload notifications to update UI
        location.reload();
      }
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };

  window.acceptConnection = async function(senderEmail) {
    try {
      const response = await fetch("http://localhost:3000/acceptConnection", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          sender: senderEmail, 
          receiver: email 
        }),
      });

      if (response.ok) {
        alert("Connection accepted!");
        // Send notification back to sender
        await fetch("http://localhost:3000/sendNotification", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sender: email,
            receiver: senderEmail,
            type: "connection_accepted",
            message: `${email} accepted your connection request`
          }),
        });
        location.reload();
      }
    } catch (error) {
      console.error("Error accepting connection:", error);
      alert("Failed to accept connection. Please try again.");
    }
  };

  window.declineConnection = async function(senderEmail) {
    if (confirm("Are you sure you want to decline this connection request?")) {
      try {
        const response = await fetch("http://localhost:3000/declineConnection", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ 
            sender: senderEmail, 
            receiver: email 
          }),
        });

        if (response.ok) {
          alert("Connection declined.");
          location.reload();
        }
      } catch (error) {
        console.error("Error declining connection:", error);
        alert("Failed to decline connection. Please try again.");
      }
    }
  };

  window.viewOrder = function(orderId) {
    // In a real app, you'd navigate to an order details page
    alert(`View order details for Order ID: ${orderId}`);
  };

  // Helper function to get default messages
  function getDefaultMessage(type, sender) {
    switch (type) {
      case 'like': return `${sender} liked your post`;
      case 'comment': return `${sender} commented on your post`;
      case 'order': return `New order received from ${sender}`;
      case 'connection': return `${sender} wants to connect with you`;
      case 'share': return `${sender} shared your post`;
      default: return `New notification from ${sender}`;
    }
  }
});
