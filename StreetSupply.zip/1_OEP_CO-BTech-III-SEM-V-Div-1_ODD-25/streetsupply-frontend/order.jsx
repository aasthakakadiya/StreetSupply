import React, { useState } from 'react';
import { Heart, ShoppingCart, Search, User, Bell, Home, Package, Plus, X } from 'lucide-react';

const OrderPage = () => {
    const [products, setProducts] = useState([
        {
            id: 1,
            name: 'Carrot',
            price: 5.00,
            unit: 'lb',
            stock: 21,
            category: 'Vegetables',
            seller: 'Coach Farm',
            tags: 'All Natural',
            size: '6',
            estPrice: 30,
            image: '🥕'
        },
        {
            id: 2,
            name: 'Fresh Eggs',
            price: 100,
            unit: 'dozen',
            stock: 15,
            category: 'Dairy or Eggs',
            seller: 'dairy@example.com',
            tags: 'Free-range',
            description: 'Farm fresh eggs from free-range chickens.',
            image: '🥚'
        }
    ]);

    const [cart, setCart] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('All Categories');
    const [searchQuery, setSearchQuery] = useState('');
    const [favorites, setFavorites] = useState(new Set());
    const [quantities, setQuantities] = useState({});
    const [userType, setUserType] = useState('buyer'); // 'buyer' or 'seller'
    const [showAddProduct, setShowAddProduct] = useState(false);

    const [newProduct, setNewProduct] = useState({
        name: '',
        price: '',
        unit: 'lb',
        stock: '',
        category: 'Vegetables',
        seller: '',
        tags: '',
        size: '',
        estPrice: '',
        description: '',
        image: '📦'
    });

    const categories = ['All Categories', 'Dairy or Eggs', 'Fruit', 'Herbs', 'Meat', 'Seafood', 'Specialty', 'Spirits', 'Vegetables'];

    const userInfo = {
        name: 'abc',
        email: 'abc@abc',
        phone: '123',
        address: 'abc',
        type: userType,
        needs: 'coco powder, butter'
    };

    const toggleFavorite = (productId) => {
        const newFavorites = new Set(favorites);
        if (newFavorites.has(productId)) {
            newFavorites.delete(productId);
        } else {
            newFavorites.add(productId);
        }
        setFavorites(newFavorites);
    };

    const addToCart = (product, quantity) => {
        if (quantity > 0) {
            const existingItem = cart.find(item => item.id === product.id);
            if (existingItem) {
                setCart(cart.map(item =>
                    item.id === product.id
                        ? { ...item, quantity: item.quantity + quantity }
                        : item
                ));
            } else {
                setCart([...cart, { ...product, quantity }]);
            }
            setQuantities({ ...quantities, [product.id]: 0 });
        }
    };

    const handleAddProduct = () => {
        if (newProduct.name && newProduct.price && newProduct.stock) {
            const productToAdd = {
                ...newProduct,
                id: Date.now(),
                price: parseFloat(newProduct.price),
                stock: parseInt(newProduct.stock),
                estPrice: newProduct.estPrice ? parseFloat(newProduct.estPrice) : 0
            };
            setProducts([...products, productToAdd]);
            setNewProduct({
                name: '',
                price: '',
                unit: 'lb',
                stock: '',
                category: 'Vegetables',
                seller: '',
                tags: '',
                size: '',
                estPrice: '',
                description: '',
                image: '📦'
            });
            setShowAddProduct(false);
        }
    };

    const filteredProducts = products.filter(product => {
        const matchesCategory = selectedCategory === 'All Categories' || product.category === selectedCategory;
        const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    return (
        <div className="min-h-screen bg-gradient-to-br from-purple-500 via-purple-600 to-blue-500">
            {/* Header */}
            <header className="bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg">
                <div className="container mx-auto px-6 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-2xl">
                            🏪
                        </div>
                        <h1 className="text-2xl font-bold">StreetSupply</h1>
                    </div>
                    <nav className="flex items-center gap-6">
                        <button className="px-6 py-2 bg-white/20 rounded-full hover:bg-white/30 transition">Home</button>
                        <button className="px-6 py-2 hover:bg-white/20 rounded-full transition">Order</button>
                        <button className="px-6 py-2 hover:bg-white/20 rounded-full transition">Notifications</button>
                        <button className="px-6 py-2 hover:bg-white/20 rounded-full transition">Profile</button>
                        <button className="px-6 py-2 bg-red-500 rounded-full hover:bg-red-600 transition">Logout</button>
                    </nav>
                </div>
            </header>

            <div className="container mx-auto px-6 py-8">
                <div className="flex gap-6">
                    {/* Left Sidebar - User Info */}
                    <div className="w-80 bg-white rounded-2xl shadow-xl p-6 h-fit sticky top-8">
                        <h2 className="text-xl font-bold mb-4 text-gray-800">Your Info</h2>
                        <div className="space-y-3 mb-6">
                            <div><span className="font-semibold">Name:</span> {userInfo.name}</div>
                            <div><span className="font-semibold">Email:</span> {userInfo.email}</div>
                            <div><span className="font-semibold">Phone:</span> {userInfo.phone}</div>
                            <div><span className="font-semibold">Address:</span> {userInfo.address}</div>
                            <div><span className="font-semibold">Type:</span> {userType}</div>
                            <div><span className="font-semibold">Needs:</span> {userInfo.needs}</div>
                        </div>

                        <div className="mb-6">
                            <label className="block text-sm font-semibold mb-2">Switch View:</label>
                            <select
                                value={userType}
                                onChange={(e) => setUserType(e.target.value)}
                                className="w-full p-2 border-2 border-purple-200 rounded-lg focus:border-purple-500 outline-none"
                            >
                                <option value="buyer">Buyer</option>
                                <option value="seller">Seller</option>
                            </select>
                        </div>

                        <h3 className="font-bold mb-3 text-gray-800 border-b-2 border-green-400 pb-2">Categories</h3>
                        <div className="space-y-2">
                            {categories.map(cat => (
                                <button
                                    key={cat}
                                    onClick={() => setSelectedCategory(cat)}
                                    className={`w-full text-left px-4 py-2 rounded-lg transition ${selectedCategory === cat
                                            ? 'bg-purple-100 text-purple-700 font-semibold'
                                            : 'hover:bg-gray-100'
                                        }`}
                                >
                                    {cat}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Center - Products */}
                    <div className="flex-1">
                        {/* Search Bar */}
                        <div className="bg-white rounded-2xl shadow-xl p-4 mb-6 flex gap-4">
                            <input
                                type="text"
                                placeholder="Search products..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="flex-1 px-6 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 outline-none text-lg"
                            />
                            <button className="bg-green-500 text-white px-8 py-3 rounded-xl hover:bg-green-600 transition font-semibold">
                                🔍 Search
                            </button>
                        </div>

                        {/* Seller Add Product Button */}
                        {userType === 'seller' && (
                            <div className="mb-6">
                                <button
                                    onClick={() => setShowAddProduct(!showAddProduct)}
                                    className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl hover:from-green-600 hover:to-green-700 transition font-semibold text-lg flex items-center justify-center gap-2"
                                >
                                    <Plus size={24} /> Add New Product
                                </button>
                            </div>
                        )}

                        {/* Add Product Form */}
                        {showAddProduct && userType === 'seller' && (
                            <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
                                <div className="flex justify-between items-center mb-4">
                                    <h3 className="text-xl font-bold">Add New Product</h3>
                                    <button onClick={() => setShowAddProduct(false)} className="text-gray-500 hover:text-red-500">
                                        <X size={24} />
                                    </button>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <input
                                        type="text"
                                        placeholder="Product Name"
                                        value={newProduct.name}
                                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    />
                                    <input
                                        type="number"
                                        placeholder="Price"
                                        value={newProduct.price}
                                        onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    />
                                    <select
                                        value={newProduct.unit}
                                        onChange={(e) => setNewProduct({ ...newProduct, unit: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    >
                                        <option value="lb">lb</option>
                                        <option value="kg">kg</option>
                                        <option value="dozen">dozen</option>
                                        <option value="liter">liter</option>
                                        <option value="piece">piece</option>
                                    </select>
                                    <input
                                        type="number"
                                        placeholder="Stock Count"
                                        value={newProduct.stock}
                                        onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    />
                                    <select
                                        value={newProduct.category}
                                        onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    >
                                        {categories.filter(c => c !== 'All Categories').map(cat => (
                                            <option key={cat} value={cat}>{cat}</option>
                                        ))}
                                    </select>
                                    <input
                                        type="text"
                                        placeholder="Seller Name/Email"
                                        value={newProduct.seller}
                                        onChange={(e) => setNewProduct({ ...newProduct, seller: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    />
                                    <input
                                        type="text"
                                        placeholder="Tags (e.g., All Natural)"
                                        value={newProduct.tags}
                                        onChange={(e) => setNewProduct({ ...newProduct, tags: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    />
                                    <input
                                        type="text"
                                        placeholder="Size"
                                        value={newProduct.size}
                                        onChange={(e) => setNewProduct({ ...newProduct, size: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    />
                                    <input
                                        type="number"
                                        placeholder="Est Price"
                                        value={newProduct.estPrice}
                                        onChange={(e) => setNewProduct({ ...newProduct, estPrice: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    />
                                    <input
                                        type="text"
                                        placeholder="Emoji (e.g., 🥕)"
                                        value={newProduct.image}
                                        onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none"
                                    />
                                    <textarea
                                        placeholder="Description"
                                        value={newProduct.description}
                                        onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                                        className="p-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 outline-none col-span-2"
                                        rows="2"
                                    />
                                </div>
                                <button
                                    onClick={handleAddProduct}
                                    className="mt-4 w-full bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition font-semibold"
                                >
                                    Add Product
                                </button>
                            </div>
                        )}

                        {/* Products Grid */}
                        <div className="bg-white rounded-2xl shadow-xl p-6">
                            <h2 className="text-2xl font-bold mb-6 text-gray-800 border-b-2 border-green-400 pb-3">
                                Available Products
                            </h2>
                            <div className="grid grid-cols-2 gap-6">
                                {filteredProducts.map(product => (
                                    <div key={product.id} className="bg-gray-50 rounded-xl p-6 shadow-md hover:shadow-xl transition relative">
                                        <button
                                            onClick={() => toggleFavorite(product.id)}
                                            className="absolute top-4 right-4"
                                        >
                                            <Heart
                                                size={24}
                                                className={favorites.has(product.id) ? 'fill-green-500 text-green-500' : 'text-gray-400'}
                                            />
                                        </button>

                                        <div className="text-6xl mb-4 text-center">{product.image}</div>

                                        <div className="text-lg font-bold mb-2">${product.price.toFixed(2)} / {product.unit}</div>
                                        <div className="text-sm text-gray-600 mb-3">{product.stock} cs</div>

                                        <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                                        <div className="text-sm text-gray-600 mb-1">{product.seller} | {product.tags}</div>
                                        <div className="text-sm text-gray-600 mb-3">Size {product.size} | Est Price ${product.estPrice}</div>

                                        {product.description && (
                                            <p className="text-sm text-gray-600 mb-4">{product.description}</p>
                                        )}

                                        <div className="flex items-center gap-3">
                                            <button
                                                onClick={() => setQuantities({ ...quantities, [product.id]: Math.max(0, (quantities[product.id] || 0) - 1) })}
                                                className="w-10 h-10 bg-gray-200 rounded-lg font-bold hover:bg-gray-300"
                                            >
                                                -
                                            </button>
                                            <input
                                                type="number"
                                                value={quantities[product.id] || 0}
                                                onChange={(e) => setQuantities({ ...quantities, [product.id]: parseInt(e.target.value) || 0 })}
                                                className="w-16 h-10 text-center border-2 border-gray-300 rounded-lg"
                                            />
                                            <button
                                                onClick={() => setQuantities({ ...quantities, [product.id]: (quantities[product.id] || 0) + 1 })}
                                                className="w-10 h-10 bg-gray-200 rounded-lg font-bold hover:bg-gray-300"
                                            >
                                                +
                                            </button>
                                            <button
                                                onClick={() => addToCart(product, quantities[product.id] || 0)}
                                                className="flex-1 bg-gray-800 text-white py-2 rounded-lg hover:bg-gray-700 transition font-semibold"
                                            >
                                                Add ${((quantities[product.id] || 0) * product.price).toFixed(2)}
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Right Sidebar - Cart */}
                    <div className="w-96 bg-white rounded-2xl shadow-xl p-6 h-fit sticky top-8">
                        <div className="flex items-center gap-2 mb-6">
                            <ShoppingCart size={24} className="text-purple-600" />
                            <h2 className="text-xl font-bold text-gray-800">Shopping Cart</h2>
                        </div>

                        {cart.length === 0 ? (
                            <p className="text-gray-500 text-center py-8">Your cart is empty</p>
                        ) : (
                            <>
                                <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
                                    {cart.map(item => (
                                        <div key={item.id} className="bg-gray-50 p-4 rounded-lg">
                                            <div className="flex justify-between items-start mb-2">
                                                <div className="font-semibold">{item.name}</div>
                                                <button
                                                    onClick={() => setCart(cart.filter(i => i.id !== item.id))}
                                                    className="text-red-500 hover:text-red-700"
                                                >
                                                    <X size={18} />
                                                </button>
                                            </div>
                                            <div className="text-sm text-gray-600">
                                                {item.quantity} × ${item.price.toFixed(2)} = ${(item.quantity * item.price).toFixed(2)}
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <div className="border-t-2 border-gray-200 pt-4 mb-4">
                                    <div className="flex justify-between items-center text-xl font-bold">
                                        <span>Total:</span>
                                        <span className="text-purple-600">₹{cartTotal.toFixed(2)}</span>
                                    </div>
                                </div>

                                <button className="w-full bg-green-500 text-white py-4 rounded-xl hover:bg-green-600 transition font-bold text-lg">
                                    Proceed to Checkout
                                </button>
                            </>
                        )}

                        <div className="mt-8">
                            <h3 className="font-bold mb-3 text-gray-800 border-b-2 border-green-400 pb-2">Suggested Products</h3>
                            <p className="text-sm text-gray-500">Based on your needs: {userInfo.needs}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OrderPage;