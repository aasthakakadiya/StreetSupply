// Global variables
let allProducts = [];
let cartItems = [];
let filteredProducts = [];
let email = null;
let userType = null;
let user = null;

// Global functions
window.addToCart = function (productId) {
  const product = allProducts.find(p => p._id === productId);
  if (!product) {
    console.error("Product not found:", productId);
    return;
  }

  const existingItem = cartItems.find(item => item._id === productId);
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cartItems.push({ ...product, quantity: 1 });
  }

  // Save cart to localStorage
  localStorage.setItem("cartItems", JSON.stringify(cartItems));

  updateCartDisplay();
  alert("Product added to cart!");
};

window.updateCartDisplay = function () {
  const cartItemsContainer = document.getElementById("cartItems");
  const cartTotal = document.getElementById("cartTotal");

  if (!cartItemsContainer || !cartTotal) {
    console.error("Cart elements not found");
    return;
  }

  cartItemsContainer.innerHTML = "";

  if (cartItems.length === 0) {
    cartItemsContainer.innerHTML = '<p>Your cart is empty</p>';
    cartTotal.textContent = "0";
    return;
  }

  let total = 0;
  cartItems.forEach(item => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const cartItem = document.createElement("div");
    cartItem.className = "cart-item";
    cartItem.innerHTML = `
      <div class="cart-item-info">
        <h4>${item.productName}</h4>
        <p>Qty: ${item.quantity}</p>
        <button onclick="removeFromCart('${item._id}')" class="remove-btn">Remove</button>
      </div>
      <div class="cart-item-price">₹${itemTotal.toFixed(2)}</div>
    `;
    cartItemsContainer.appendChild(cartItem);
  });

  cartTotal.textContent = total.toFixed(2);
};

window.removeFromCart = function (productId) {
  cartItems = cartItems.filter(item => item._id !== productId);
  localStorage.setItem("cartItems", JSON.stringify(cartItems));
  updateCartDisplay();
};

window.showPaymentModal = function () {
  const cartItemsContainer = document.getElementById("cartItems");
  if (!cartItemsContainer) {
    console.error("Cart items container not found");
    return;
  }

  if (cartItems.length === 0) {
    alert("Your cart is empty!");
    return;
  }

  const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const paymentAmount = document.getElementById("paymentAmount");
  const paymentModal = document.getElementById("paymentModal");

  if (paymentAmount) {
    paymentAmount.textContent = total.toFixed(2);
  }

  if (paymentModal) {
    paymentModal.style.display = "block";
  }
};

// Open modal
document.getElementById("openPayment").onclick = function () {
  document.getElementById("paymentModal").style.display = "block";
  document.getElementById("paymentAmount").textContent = 500; // Example amount
}

// Close modal
document.querySelector(".close").onclick = function () {
  document.getElementById("paymentModal").style.display = "none";
}

// Close when clicking outside
window.onclick = function (event) {
  if (event.target == document.getElementById("paymentModal")) {
    document.getElementById("paymentModal").style.display = "none";
  }
}

// Payment submit
document.getElementById("paymentForm").onsubmit = function (e) {
  e.preventDefault();
  alert("Payment Successful!");
  document.getElementById("paymentModal").style.display = "none";
}


document.addEventListener("DOMContentLoaded", async () => {
  email = sessionStorage.getItem("email");
  userType = sessionStorage.getItem("userType");

  // If userType is not in sessionStorage, try to get it from localStorage
  if (!userType) {
    userType = localStorage.getItem("userRole");
  }

  // Check if user is logged in
  if (!email) {
    alert("Please log in first.");
    window.location.href = "index.html";
    return;
  }

  // If still no userType, set a default or redirect
  if (!userType) {
    alert("User type not found. Please log in again.");
    window.location.href = "index.html";
    return;
  }

  // Load cart items from localStorage
  try {
    const savedCart = localStorage.getItem("cartItems");
    if (savedCart) {
      cartItems = JSON.parse(savedCart);
    }
  } catch (e) {
    console.error("Error loading cart from localStorage:", e);
    cartItems = [];
  }

  // Get user details
  try {
    const userRes = await fetch('http://localhost:3000/getUser', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email })
    });
    user = await userRes.json();
  } catch (err) {
    console.error('Failed to fetch user:', err);
    user = { userType: userType, email: email };
  }

  // DOM elements
  const searchBar = document.getElementById("searchBar");
  const searchBtn = document.getElementById("searchBtn");
  const sellerControls = document.getElementById("sellerControls");
  const addProductBtn = document.getElementById("addProductBtn");
  const addProductFormContainer = document.getElementById("addProductFormContainer");
  const addProductForm = document.getElementById("addProductForm");
  const cancelBtn = document.getElementById("cancelBtn");
  const userInfoContent = document.getElementById("userInfoContent");
  const categoriesList = document.getElementById("categoriesList");
  const mainHeading = document.getElementById("mainHeading");
  const sellerProductsSection = document.getElementById("sellerProductsSection");
  const sellerProducts = document.getElementById("sellerProducts");
  const allProductsSection = document.getElementById("allProductsSection");
  const allProductsGrid = document.getElementById("allProducts");
  const productsSectionTitle = document.getElementById("productsSectionTitle");
  const shoppingCart = document.getElementById("shoppingCart");
  const cartItemsContainer = document.getElementById("cartItems");
  const cartTotal = document.getElementById("cartTotal");
  const checkoutBtn = document.getElementById("checkoutBtn");
  const suggestedProducts = document.getElementById("suggestedProducts");
  const categoryFilter = document.getElementById("categoryFilter");
  const sortFilter = document.getElementById("sortFilter");
  const noProductsMessage = document.getElementById("noProductsMessage");
  const paymentModal = document.getElementById("paymentModal");
  const paymentForm = document.getElementById("paymentForm");
  const paymentAmount = document.getElementById("paymentAmount");
  const closeModal = document.querySelector(".close");
  const logoutBtn = document.getElementById("logoutBtn");

  function initializePage() {
    // Set user info
    userInfoContent.innerHTML = `
      <p><strong>Name:</strong> ${user.fullName || "N/A"}</p>
      <p><strong>Email:</strong> ${user.email || email}</p>
      <p><strong>Phone:</strong> ${user.phone || "N/A"}</p>
      <p><strong>Address:</strong> ${user.address || "N/A"}</p>
      <p><strong>Type:</strong> ${user.userType || userType}</p>
      ${(user.userType || userType) === "buyer"
        ? `<p><strong>Needs:</strong> ${user.ingredientsNeeded || user.needItems?.join(", ") || "None"}</p>`
        : `<p><strong>Selling:</strong> ${user.whatTheySell || user.sellItems?.join(", ") || "None"}</p>`
      }
    `;

    // Set main heading
    mainHeading.innerText = (user.userType || userType) === "buyer" ? "Available Products" : "Manage Your Products";

    // Show seller controls for sellers
    if ((user.userType || userType) === "seller") {
      sellerControls.style.display = "block";
      sellerProductsSection.style.display = "block";
      productsSectionTitle.innerText = "Similar Products by Other Sellers";
    } else {
      shoppingCart.style.display = "block";
      productsSectionTitle.innerText = "All Available Products";
      updateCartDisplay();
    }

    // Load categories
    loadCategories();
  }

  async function loadProducts() {
    try {
      console.log("=== LOADING PRODUCTS ===");
      const response = await fetch("http://localhost:3000/getProducts");
      console.log("Response status:", response.status);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      allProducts = await response.json();
      console.log("Loaded products:", allProducts);
      console.log("Number of products loaded:", allProducts.length);

      // Load local products and merge with backend products
      loadLocalProducts();

      filteredProducts = [...allProducts];

      // Force render products immediately
      renderProducts();
      loadSuggestedProducts();
    } catch (error) {
      console.error("Error loading products:", error);
      // If getProducts fails, try to get posts as products
      try {
        console.log("Trying to load posts as products...");
        const response = await fetch("http://localhost:3000/getPosts");
        const posts = await response.json();
        allProducts = posts.map(post => ({
          _id: post._id,
          productName: post.title || post.content?.substring(0, 50) || "Product",
          description: post.content || "No description",
          category: post.tags?.[0] || "General",
          price: post.price || Math.floor(Math.random() * 1000) + 100, // Random price if not available
          sellerEmail: post.userEmail || "unknown"
        }));

        // Load local products and merge with posts
        loadLocalProducts();

        filteredProducts = [...allProducts];
        renderProducts();
        loadSuggestedProducts();
      } catch (err) {
        console.error("Error loading posts as products:", err);
        // Create sample products for demonstration
        createSampleProducts();
        // Load local products and merge with sample products
        loadLocalProducts();
      }
    }
  }

  function loadLocalProducts() {
    try {
      const localProducts = JSON.parse(localStorage.getItem('localProducts') || '[]');
      if (localProducts.length > 0) {
        console.log("Loading local products:", localProducts);
        // Merge local products with existing products, avoiding duplicates
        const existingIds = allProducts.map(p => p._id);
        const newLocalProducts = localProducts.filter(p => !existingIds.includes(p._id));
        allProducts = [...allProducts, ...newLocalProducts];
        console.log("Total products after merging:", allProducts.length);
      }
    } catch (error) {
      console.error("Error loading local products:", error);
    }
  }

  function createSampleProducts() {
    console.log("Creating sample products for demonstration...");

    const sampleProducts = [
      {
        _id: "prod_1",
        productName: "Fresh Organic Tomatoes",
        description: "Fresh, organic tomatoes grown locally. Perfect for salads and cooking.",
        category: "Vegetables",
        price: 150,
        sellerEmail: "farmer1@example.com"
      },
      {
        _id: "prod_2",
        productName: "Premium Quality Rice",
        description: "High-quality basmati rice, perfect for daily cooking needs.",
        category: "Grains",
        price: 80,
        sellerEmail: "seller2@example.com"
      },
      {
        _id: "prod_3",
        productName: "Fresh Milk",
        description: "Pure, fresh milk from local dairy farms. Available daily.",
        category: "Dairy",
        price: 60,
        sellerEmail: "dairy@example.com"
      },
      {
        _id: "prod_4",
        productName: "Organic Potatoes",
        description: "Fresh organic potatoes, great for various recipes.",
        category: "Vegetables",
        price: 120,
        sellerEmail: "farmer1@example.com"
      },
      {
        _id: "prod_5",
        productName: "Whole Wheat Bread",
        description: "Freshly baked whole wheat bread, healthy and nutritious.",
        category: "Bakery",
        price: 45,
        sellerEmail: "baker@example.com"
      },
      {
        _id: "prod_6",
        productName: "Fresh Eggs",
        description: "Farm fresh eggs from free-range chickens.",
        category: "Dairy",
        price: 100,
        sellerEmail: "dairy@example.com"
      },
      {
        _id: "prod_7",
        productName: "Organic Onions",
        description: "Fresh organic onions, essential for every kitchen.",
        category: "Vegetables",
        price: 90,
        sellerEmail: "farmer1@example.com"
      },
      {
        _id: "prod_8",
        productName: "Pure Honey",
        description: "Natural honey from local beekeepers. No additives.",
        category: "Natural Products",
        price: 200,
        sellerEmail: "beekeeper@example.com"
      }
    ];

    allProducts = sampleProducts;
    filteredProducts = [...allProducts];

    console.log("Sample products created:", allProducts);
    renderProducts();
    loadSuggestedProducts();
  }

  function renderProducts() {
    console.log("=== RENDERING PRODUCTS ===");
    console.log("User type:", user.userType || userType);
    console.log("All products count:", allProducts.length);
    console.log("All products:", allProducts);

    // Filter products based on user type
    let productsToShow = [];

    if ((user.userType || userType) === "seller") {
      // Show seller's own products
      const sellerProductsList = allProducts.filter(p => p.sellerEmail === email);
      console.log("Seller's products:", sellerProductsList);
      renderSellerProducts(sellerProductsList);

      // Show similar products by other sellers
      const userSellItems = user.whatTheySell || user.sellItems || [];
      const similarProducts = allProducts.filter(p =>
        p.sellerEmail !== email &&
        (userSellItems.length === 0 || userSellItems.some(item =>
          p.category.toLowerCase().includes(item.toLowerCase()) ||
          p.productName.toLowerCase().includes(item.toLowerCase())
        ))
      );
      productsToShow = similarProducts;
      console.log("Similar products for seller:", similarProducts);

      // Update the section title to be more descriptive
      if (productsSectionTitle) {
        productsSectionTitle.innerText = "Similar Products by Other Sellers";
      }
    } else {
      // Show all products for buyers
      productsToShow = allProducts;
      console.log("All products for buyer:", productsToShow);

      // Update the section title to be more descriptive
      if (productsSectionTitle) {
        productsSectionTitle.innerText = "All Available Products";
      }
    }

    // Apply search filter
    if (searchBar && searchBar.value.trim()) {
      const searchTerm = searchBar.value.toLowerCase();
      productsToShow = productsToShow.filter(product =>
        product.productName.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm)
      );
    }

    // Apply category filter
    if (categoryFilter && categoryFilter.value) {
      productsToShow = productsToShow.filter(product =>
        product.category.toLowerCase() === categoryFilter.value.toLowerCase()
      );
    }

    // Apply sorting
    sortProducts(productsToShow);

    console.log("Final products to show:", productsToShow);
    console.log("Final products count:", productsToShow.length);

    // Render products
    if (productsToShow.length === 0) {
      console.log("No products to show, displaying no products message");
      showNoProductsMessage();
    } else {
      console.log("Showing products:", productsToShow.length);
      hideNoProductsMessage();
      renderProductGrid(productsToShow, allProductsGrid);
    }
  }

  function renderSellerProducts(products) {
    if (products.length === 0) {
      sellerProducts.innerHTML = `
        <div class="no-products-message">
          <p>You haven't added any products yet.</p>
          <p>Click the "Add New Product" button above to start selling!</p>
        </div>
      `;
    } else {
      renderProductGrid(products, sellerProducts, true);
    }
  }

  function renderProductGrid(products, container, isSellerView = false) {
    console.log("=== RENDERING PRODUCT GRID ===");
    console.log("Rendering product grid with", products.length, "products");
    console.log("Container:", container);
    console.log("Container ID:", container ? container.id : "No ID");
    console.log("Is seller view:", isSellerView);

    if (!container) {
      console.error("Container element not found!");
      return;
    }

    container.innerHTML = "";

    if (products.length === 0) {
      console.log("No products to render");
      container.innerHTML = '<p>No products available</p>';
      return;
    }

    products.forEach((product, index) => {
      console.log("Rendering product", index + 1, ":", product);

      const card = document.createElement("div");
      card.className = "product-card";

      const actions = isSellerView
        ? `
          <div class="product-actions">
            <button class="edit-product-btn" onclick="editProduct('${product._id}')">Edit</button>
            <button class="delete-product-btn" onclick="deleteProduct('${product._id}')">Delete</button>
          </div>
        `
        : (user.userType || userType) === "buyer"
          ? `
          <div class="product-actions">
            <button class="add-to-cart-btn" onclick="addToCart('${product._id}')">Add to Cart</button>
          </div>
        `
          : `
          <div class="product-actions">
            <button class="contact-seller-btn" onclick="contactSeller('${product.sellerEmail}')">Contact Seller</button>
          </div>
        `;

      card.innerHTML = `
        <h4>${product.productName || 'No Name'}</h4>
        <p>${product.description || 'No Description'}</p>
        <p><strong>Category:</strong> ${product.category || 'No Category'}</p>
        <div class="price">₹${product.price || 0}</div>
        <div class="seller-info">Seller: ${product.sellerEmail || 'Unknown'}</div>
        ${actions}
      `;

      container.appendChild(card);
      console.log("Added product card to container");
    });

    console.log("Finished rendering product grid");
  }

  function loadCategories() {
    const categories = [...new Set(allProducts.map(p => p.category))];
    categoriesList.innerHTML = `
      <ul>
        <li onclick="filterByCategory('')">All Categories</li>
        ${categories.map(category => `
          <li onclick="filterByCategory('${category}')">${category}</li>
        `).join('')}
    </ul>
  `;

    // Populate category filter dropdown
    categoryFilter.innerHTML = `
      <option value="">All Categories</option>
      ${categories.map(category => `
        <option value="${category}">${category}</option>
      `).join('')}
    `;
  }

  function loadSuggestedProducts() {
    if ((user.userType || userType) === "buyer") {
      const userNeedItems = user.ingredientsNeeded || user.needItems || [];
      const suggested = allProducts.filter(product =>
        userNeedItems.length === 0 || userNeedItems.some(item =>
          product.category.toLowerCase().includes(item.toLowerCase()) ||
          product.productName.toLowerCase().includes(item.toLowerCase())
        )
      ).slice(0, 5);

      suggestedProducts.innerHTML = "";
      if (suggested.length === 0) {
        suggestedProducts.innerHTML = '<p>No suggestions available</p>';
      } else {
        suggested.forEach(product => {
          const card = document.createElement("div");
          card.className = "suggested-card";
          card.innerHTML = `
            <h4>${product.productName}</h4>
            <div class="price">₹${product.price}</div>
            <p>${product.category}</p>
          `;
          suggestedProducts.appendChild(card);
        });
      }
    }
  }

  function setupEventListeners() {
    // Search functionality
    searchBtn.addEventListener("click", () => renderProducts());
    searchBar.addEventListener("keypress", (e) => {
      if (e.key === "Enter") renderProducts();
    });

    // Add product form
    if (addProductBtn) {
      addProductBtn.addEventListener("click", () => {
        addProductFormContainer.style.display =
          addProductFormContainer.style.display === "none" ? "block" : "none";
      });
    }

    if (cancelBtn) {
      cancelBtn.addEventListener("click", () => {
        addProductFormContainer.style.display = "none";
        addProductForm.reset();
      });
    }

    // Form submission
    if (addProductForm) {
      addProductForm.addEventListener("submit", handleAddProduct);
    }

    // Filters
    categoryFilter.addEventListener("change", renderProducts);
    sortFilter.addEventListener("change", renderProducts);

    // Checkout
    if (checkoutBtn) {
      checkoutBtn.addEventListener("click", showPaymentModal);
    }

    // Payment modal
    if (closeModal) {
      closeModal.addEventListener("click", () => {
        paymentModal.style.display = "none";
      });
    }

    if (paymentForm) {
      paymentForm.addEventListener("submit", handlePayment);
    }

    // Close modal when clicking outside
    window.addEventListener("click", (e) => {
      if (e.target === paymentModal) {
        paymentModal.style.display = "none";
      }
    });

    // Logout functionality
    if (logoutBtn) {
      logoutBtn.addEventListener("click", () => {
        sessionStorage.clear();
        localStorage.clear();
        alert("Logged out successfully!");
        window.location.href = "index.html";
      });
    }
  }

  async function handleAddProduct(e) {
    e.preventDefault();

    const formData = new FormData(addProductForm);
    const product = {
      _id: "prod_" + Date.now(), // Generate unique ID
      sellerEmail: email,
      productName: formData.get("productName"),
      category: formData.get("category"),
      price: parseFloat(formData.get("price")),
      description: formData.get("description"),
      createdAt: new Date().toISOString()
    };

    // Debug logging
    console.log("Form data:", {
      sellerEmail: email,
      productName: formData.get("productName"),
      category: formData.get("category"),
      price: formData.get("price"),
      description: formData.get("description")
    });

    // Validate form data
    if (!product.productName || !product.category || !product.price || !product.description) {
      alert("Please fill in all required fields");
      return;
    }

    if (isNaN(product.price) || product.price <= 0) {
      alert("Please enter a valid price");
      return;
    }

    try {
      console.log("Sending product data:", product);

      const response = await fetch("http://localhost:3000/addProduct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(product)
      });

      console.log("Response status:", response.status);
      const result = await response.json();
      console.log("Response result:", result);

      if (result.success || result.message === "Product added successfully" || result.message === "Product added successfully!") {
        alert("Product added successfully!");
        addProductForm.reset();
        addProductFormContainer.style.display = "none";
        await loadProducts(); // Reload products
      } else {
        alert(result.message || "Failed to add product");
      }
    } catch (error) {
      console.error("Error adding product:", error);
      // Fallback to local storage when backend is not available
      addProductToLocalStorage(product);
    }
  }

  function addProductToLocalStorage(product) {
    try {
      // Get existing products from localStorage
      let localProducts = JSON.parse(localStorage.getItem('localProducts') || '[]');

      // Add new product
      localProducts.push(product);

      // Save back to localStorage
      localStorage.setItem('localProducts', JSON.stringify(localProducts));

      // Add to current products array
      allProducts.push(product);
      filteredProducts = [...allProducts];

      // Re-render products
      renderProducts();
      loadSuggestedProducts();

      alert("Product added successfully! (Saved locally)");
      addProductForm.reset();
      addProductFormContainer.style.display = "none";

      console.log("Product added to local storage:", product);
    } catch (error) {
      console.error("Error saving product to local storage:", error);
      alert("Failed to save product locally: " + error.message);
    }
  }

  async function handlePayment(e) {
    e.preventDefault();

    // Get payment form data
    const formData = new FormData(paymentForm);
    const cardNumber = formData.get("cardNumber");
    const cardHolder = formData.get("cardHolder");
    const expiry = formData.get("expiry");
    const cvv = formData.get("cvv");

    // Validate form data
    if (!cardNumber || !cardHolder || !expiry || !cvv) {
      alert("Please fill in all payment details");
      return;
    }

    // Additional validation for card number (basic)
    if (cardNumber.replace(/\s/g, '').length < 16) {
      alert("Please enter a valid card number (16 digits)");
      return;
    }

    // Additional validation for CVV (basic)
    if (cvv.length < 3 || cvv.length > 4) {
      alert("Please enter a valid CVV (3-4 digits)");
      return;
    }

    // Show processing message
    const paymentBtn = paymentForm.querySelector(".payment-btn");
    const originalBtnText = paymentBtn.textContent;
    paymentBtn.textContent = "Processing...";
    paymentBtn.disabled = true;

    try {
      // In a real application, you would integrate with a payment gateway here
      console.log("Processing payment:", { cardNumber, cardHolder, expiry, cvv });

      // Create order record
      const orderData = {
        buyerEmail: email,
        items: cartItems.map(item => ({
          productId: item._id,
          productName: item.productName,
          price: item.price,
          quantity: item.quantity
        })),
        total: cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        paymentMethod: "Card",
        timestamp: new Date().toISOString()
      };

      // Send order to backend
      const response = await fetch("http://localhost:3000/createOrder", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData)
      });

      if (response.ok) {
        const result = await response.json();
        alert("Payment processed successfully! Order placed.");

        // Send notification to sellers
        for (const item of cartItems) {
          try {
            await fetch("http://localhost:3000/sendNotification", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                sender: email,
                receiver: item.sellerEmail,
                type: "order",
                message: `New order received for ${item.productName} (Qty: ${item.quantity})`,
                orderId: result.orderId
              })
            });
          } catch (err) {
            console.error("Failed to send notification:", err);
          }
        }

        // Clear cart
        cartItems = [];
        localStorage.removeItem("cartItems");
        updateCartDisplay();

        // Close modal and reset form
        paymentModal.style.display = "none";
        paymentForm.reset();
      } else {
        const error = await response.json();
        alert("Payment failed: " + (error.message || "Unknown error"));
      }
    } catch (error) {
      console.error("Payment error:", error);
      // Check if it's a network error
      if (error instanceof TypeError) {
        alert("Payment failed: Network error. Please check your connection and try again.");
      } else {
        alert("Payment failed: " + (error.message || "Unknown error"));
      }
    } finally {
      // Reset button state
      paymentBtn.textContent = originalBtnText;
      paymentBtn.disabled = false;
    }
  }

  function sortProducts(products) {
    const sortBy = sortFilter.value;

    switch (sortBy) {
      case "price-low":
        products.sort((a, b) => a.price - b.price);
        break;
      case "price-high":
        products.sort((a, b) => b.price - a.price);
        break;
      case "name":
      default:
        products.sort((a, b) => a.productName.localeCompare(b.productName));
        break;
    }
  }

  function showNoProductsMessage() {
    console.log("Showing no products message");
    if (noProductsMessage) {
      noProductsMessage.style.display = "block";
    }
    if (allProductsGrid) {
      allProductsGrid.innerHTML = "";
    }
  }

  function hideNoProductsMessage() {
    console.log("Hiding no products message");
    if (noProductsMessage) {
      noProductsMessage.style.display = "none";
    }
  }

  // Initialize page
  initializePage();
  await loadProducts();
  setupEventListeners();

  // Global functions for onclick handlers
  window.editProduct = function (productId) {
    // Implement edit functionality
    alert("Edit functionality to be implemented");
  };

  window.deleteProduct = async function (productId) {
    if (confirm("Are you sure you want to delete this product?")) {
      try {
        const response = await fetch(`http://localhost:3000/deleteProduct/${productId}`, {
          method: "DELETE"
        });

        const result = await response.json();
        if (result.success) {
          alert("Product deleted successfully!");
          await loadProducts();
        } else {
          alert(result.message || "Failed to delete product");
        }
      } catch (error) {
        console.error("Error deleting product:", error);
        // Fallback to local storage when backend is not available
        deleteProductFromLocalStorage(productId);
      }
    }
  };

  function deleteProductFromLocalStorage(productId) {
    try {
      // Remove from allProducts array
      allProducts = allProducts.filter(p => p._id !== productId);
      filteredProducts = [...allProducts];

      // Remove from localStorage
      let localProducts = JSON.parse(localStorage.getItem('localProducts') || '[]');
      localProducts = localProducts.filter(p => p._id !== productId);
      localStorage.setItem('localProducts', JSON.stringify(localProducts));

      // Re-render products
      renderProducts();
      loadSuggestedProducts();

      alert("Product deleted successfully! (Removed from local storage)");
      console.log("Product deleted from local storage:", productId);
    } catch (error) {
      console.error("Error deleting product from local storage:", error);
      alert("Failed to delete product locally: " + error.message);
    }
  }

  window.contactSeller = function (sellerEmail) {
    alert(`Contact seller at: ${sellerEmail}`);
  };

  window.filterByCategory = function (category) {
    categoryFilter.value = category;
    renderProducts();
  };

  // Debug function to clear local storage (for testing)
  window.clearLocalProducts = function () {
    if (confirm("Are you sure you want to clear all local products? This cannot be undone.")) {
      localStorage.removeItem('localProducts');
      alert("Local products cleared! Refresh the page to see sample products again.");
      location.reload();
    }
  };

  // Debug function to show current products
  window.showCurrentProducts = function () {
    console.log("Current allProducts:", allProducts);
    console.log("Current filteredProducts:", filteredProducts);
    console.log("Local storage products:", JSON.parse(localStorage.getItem('localProducts') || '[]'));
    alert(`Total products: ${allProducts.length}\nFiltered products: ${filteredProducts.length}\nCheck console for details.`);
  };
});
