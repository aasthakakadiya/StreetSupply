function switchTab(tab) {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const loginTab = document.getElementById('loginTab');
  const registerTab = document.getElementById('registerTab');

  loginTab.classList.remove('active');
  registerTab.classList.remove('active');

  if (tab === 'login') {
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
    loginTab.classList.add('active');
  } else {
    registerForm.classList.remove('hidden');
    loginForm.classList.add('hidden');
    registerTab.classList.add('active');
  }
}

document.getElementById('loginTab').addEventListener('click', () => switchTab('login'));
document.getElementById('registerTab').addEventListener('click', () => switchTab('register'));

document.getElementById('buyerBtn').onclick = () => {
  document.getElementById('buyerBtn').classList.add('active');
  document.getElementById('sellerBtn').classList.remove('active');
  document.getElementById('loginRole').value = 'buyer';
  document.getElementById('registerRole').value = 'buyer';
};

document.getElementById('sellerBtn').onclick = () => {
  document.getElementById('sellerBtn').classList.add('active');
  document.getElementById('buyerBtn').classList.remove('active');
  document.getElementById('loginRole').value = 'seller';
  document.getElementById('registerRole').value = 'seller';
};

document.getElementById('loginForm').onsubmit = async function (e) {
  e.preventDefault();
  const formData = new FormData(this);
  const data = Object.fromEntries(formData.entries());

  const res = await fetch('http://localhost:3000/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  const result = await res.json();

  if (result.success) {
    showPopup('Login successful!');
    sessionStorage.setItem("email", data.email); // save session
    sessionStorage.setItem("userType", data.role || result.user?.userType); // Save userType to sessionStorage
    localStorage.setItem("userRole", data.role); // ✅ Save role for checking later
    window.location.href = "home.html"; // redirect to home page
  } else {
    showPopup(result.message || 'Login failed.');
  }
};
document.getElementById('registerForm').onsubmit = async function (e) {
  e.preventDefault();
  console.log("Register form submitted");

  const formData = new FormData(this);
  const data = Object.fromEntries(formData.entries());

  if (data.password !== data.confirmPassword) {
    showPopup("Passwords do not match");
    return;
  }

  // Register the user
  const res = await fetch('http://localhost:3000/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userType: data.role,           // important: use 'userType'
      fullName: data.fullName,
      phone: data.phone,
      email: data.email,
      address: data.address,
      pincode: data.pincode,
      location: data.location,
      password: data.password
    })
  });

  const result = await res.json();
  showPopup(result.message);

  // Auto-login if registration is successful
  if (result.message === 'User registered successfully.') {
    const loginRes = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: data.email,
        password: data.password
      })
    });

    const loginResult = await loginRes.json();
    if (loginResult.success) {
      sessionStorage.setItem("email", data.email);
      sessionStorage.setItem("userType", data.role || loginResult.user?.userType); // Save userType
      window.location.href = "home.html";
    }
  }
};


function showPopup(message) {
  const popup = document.getElementById('popupMessage');
  popup.textContent = message;
  popup.style.display = 'block';
  setTimeout(() => popup.style.display = 'none', 3000);
}

function showUserDetails(user) {
  document.getElementById('authContainer').style.display = 'none';
  document.getElementById('userDetails').style.display = 'block';

  document.getElementById('userName').textContent = user.fullName;
  document.getElementById('userPhone').textContent = user.phone;
  document.getElementById('userEmail').textContent = user.email;
  document.getElementById('userAddress').textContent = user.address;
  document.getElementById('userPincode').textContent = user.pincode;
  document.getElementById('userLocation').href = user.location;
  document.getElementById('userRole').textContent = user.role;
}
