document.addEventListener('DOMContentLoaded', async function () {
  const userType = localStorage.getItem('userType');

  // DOM elements
  const userName = document.getElementById('userName');
  const userPhone = document.getElementById('userPhone');
  const userAddress = document.getElementById('userAddress');
  const label1 = document.getElementById('label1');
  const value1 = document.getElementById('value1');
  const label2 = document.getElementById('label2');
  const value2 = document.getElementById('value2');
  const extraInfo = document.getElementById('extraInfo');
  const userEmail = sessionStorage.getItem("email");

  // Fetch user details
  try {
    const res = await fetch('http://localhost:3000/getUser', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: userEmail })
    });
    const user = await res.json();
    console.log(user);

    userName.textContent = user.fullName;
    userPhone.textContent = user.phone;
    userAddress.textContent = user.address;

    if (user.userType === 'seller') {
      label1.textContent = 'sells:';
      value1.textContent = 'Potatoes, Onions';
      extraInfo.style.display = 'none';
      document.querySelector('.suggestions-title').textContent = 'Recommended Sellers';
    } else {
      label1.textContent = 'Sells:';
      value1.textContent = 'Potatoes, Onions';
      label2.textContent = 'Needs:';
      value2.textContent = 'Seeds, Fertilizers';
      extraInfo.style.display = 'block';
      document.querySelector('.suggestions-title').textContent = 'Potential Buyers';
    }
  } catch (err) {
    console.error('Failed to fetch user:', err);
  }

  async function getUserInfo() {
  const email = sessionStorage.getItem("email");
  if (!email) return;

  try {
    const res = await fetch("http://localhost:3000/getUser", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email }),
    });

    const user = await res.json();

    // ✅ Populate left sidebar
    document.getElementById("userName").textContent = user.fullName || "";
    document.getElementById("userPhone").textContent =  (user.phone || "");
    document.getElementById("userAddress").textContent =  (user.address || "");
    document.getElementById("userEmail").textContent = user.email || "";
    document.getElementById("value1").textContent = user.whatTheySell || "";
    document.getElementById("value2").textContent = user.ingredientsNeeded || "";
    document.getElementById("userType").textContent = user.userType || "";

    if (user.role === "buyer") {
      document.getElementById("userRoleInfo").textContent =
        "Food Sold: " + (user.foodSold || "") +
        "\nRaw Materials Needed: " + (user.rawMaterialsNeeded || "");
    } else {
      document.getElementById("userRoleInfo").textContent =
        "Raw Materials Sold: " + (user.rawMaterialsSold || "");
    }

  } catch (error) {
    console.error("Failed to load user data:", error);
  }
}
  getUserInfo();

document.getElementById("updateProfileBtn").addEventListener("click", () => {
  window.location.href = "profile.html";
});

// Logout functionality
document.getElementById("logoutBtn").addEventListener("click", () => {
  sessionStorage.clear();
  localStorage.clear();
  alert("Logged out successfully!");
  window.location.href = "index.html";
});

  // Load user posts
  async function loadUserPosts() {
    const res = await fetch('http://localhost:3000/getPosts');
    const posts = await res.json();
    const feed = document.getElementById('postFeed');
    feed.innerHTML = '';

    posts.forEach(post => {
      const postDiv = document.createElement('div');
      postDiv.className = 'post';
      postDiv.setAttribute("data-post-id", post._id); // very important!
      postDiv.innerHTML = `
        <div class="post-header">
          <strong>${post.userEmail}</strong>
          <span class="post-time">${new Date(post.createdAt).toLocaleString()}</span>
        </div>
        <div class="post-content">${post.content}</div>
        ${post.imageUrl ? `<img src="${post.imageUrl}" alt="Post Image" class="post-image">` : ''}
        <div class="post-actions">
          <button class="like-btn" data-post-id="${post._id}" data-likes="${post.likes || 0}">
            👍 Like (${post.likes || 0})
          </button>
          <button class="comment-btn" data-post-id="${post._id}">
            💬 Comment (${post.comments?.length || 0})
          </button>
          <button class="share-btn" data-post-id="${post._id}">
            📤 Share
          </button>
        </div>
        <div class="comments-section" id="comments-${post._id}" style="display: none;">
          <div class="comments-list" id="comments-list-${post._id}">
            ${(post.comments || []).map(comment => `
              <div class="comment">
                <strong>${comment.userEmail}:</strong> ${comment.content}
                <small>${new Date(comment.timestamp).toLocaleString()}</small>
              </div>
            `).join('')}
          </div>
          <div class="add-comment">
            <input type="text" class="comment-input" placeholder="Write a comment..." data-post-id="${post._id}">
            <button class="submit-comment-btn" data-post-id="${post._id}">Post</button>
          </div>
        </div>
      `;
      feed.appendChild(postDiv);
    });

    // Attach event listeners after creating posts
    attachPostEventListeners();
  }

  async function loadNotificationCount() {
  const email = sessionStorage.getItem("email");
  const res = await fetch("http://localhost:3000/getNotifications", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });

  const notifications = await res.json();
  const unread = notifications.filter(n => !n.read).length;
  const countSpan = document.getElementById("notifCount");
  if (unread > 0) {
    countSpan.textContent = unread;
  } else {
    countSpan.textContent = "";
  }
}

loadNotificationCount();

  // Post creation
  const postInput = document.querySelector('.post-input');
  const postBtn = document.querySelector('.post-btn');
  const feed = document.getElementById('postFeed');

  postBtn.addEventListener('click', async () => {
    const content = postInput.value.trim();
    if (!content) return;

    const res = await fetch('http://localhost:3000/createPost', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userEmail, content })
    });
    const data = await res.json();

    if (data.success) {
      loadUserPosts(); // Refresh posts
      postInput.value = '';
    }
  });

  // Load posts
  loadUserPosts();

  // Attach event listeners for post interactions
  function attachPostEventListeners() {
    // Like buttons
    document.querySelectorAll('.like-btn').forEach(btn => {
      btn.addEventListener('click', async function () {
        const postId = this.getAttribute('data-post-id');
        const currentLikes = parseInt(this.getAttribute('data-likes'));
        const newLikes = currentLikes + 1;
        
        // Update button text immediately for better UX
        this.textContent = `👍 Like (${newLikes})`;
        this.setAttribute('data-likes', newLikes);

        const sender = sessionStorage.getItem("email");
        const postDiv = this.closest('.post');
        const receiver = postDiv.querySelector('.post-header strong').textContent;

        try {
          // Update likes in backend
          await fetch("http://localhost:3000/updatePostLikes", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ postId, likes: newLikes })
          });

          // Send notification
          await fetch("http://localhost:3000/sendNotification", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              sender,
              receiver,
              type: "like",
              postId,
              message: `${sender} liked your post`
            }),
          });

          // Update notification count
          loadNotificationCount();
        } catch (error) {
          console.error("Error updating like:", error);
          // Revert the button if there's an error
          this.textContent = `👍 Like (${currentLikes})`;
          this.setAttribute('data-likes', currentLikes);
        }
      });
    });

    // Comment buttons
    document.querySelectorAll('.comment-btn').forEach(btn => {
      btn.addEventListener('click', function () {
        const postId = this.getAttribute('data-post-id');
        const commentsSection = document.getElementById(`comments-${postId}`);
        const isVisible = commentsSection.style.display !== 'none';
        
        commentsSection.style.display = isVisible ? 'none' : 'block';
        this.textContent = isVisible ? 
          `💬 Comment (${commentsSection.querySelectorAll('.comment').length})` : 
          '💬 Comment (Hide)';
      });
    });

    // Submit comment buttons
    document.querySelectorAll('.submit-comment-btn').forEach(btn => {
      btn.addEventListener('click', async function () {
        const postId = this.getAttribute('data-post-id');
        const commentInput = document.querySelector(`.comment-input[data-post-id="${postId}"]`);
        const commentText = commentInput.value.trim();
        
        if (!commentText) return;

        const sender = sessionStorage.getItem("email");
        const postDiv = this.closest('.post');
        const receiver = postDiv.querySelector('.post-header strong').textContent;

        try {
          // Add comment to backend
          const response = await fetch("http://localhost:3000/addComment", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              postId,
              userEmail: sender,
              content: commentText
            })
          });

          if (response.ok) {
            // Add comment to UI
            const commentsList = document.getElementById(`comments-list-${postId}`);
            const commentDiv = document.createElement('div');
            commentDiv.className = 'comment';
            commentDiv.innerHTML = `
              <strong>${sender}:</strong> ${commentText}
              <small>${new Date().toLocaleString()}</small>
            `;
            commentsList.appendChild(commentDiv);

            // Clear input
            commentInput.value = '';

            // Update comment count
            const commentBtn = document.querySelector(`.comment-btn[data-post-id="${postId}"]`);
            const commentCount = commentsList.querySelectorAll('.comment').length;
            commentBtn.textContent = `💬 Comment (${commentCount})`;

            // Send notification
            await fetch("http://localhost:3000/sendNotification", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                sender,
                receiver,
                type: "comment",
                postId,
                message: `${sender} commented on your post: "${commentText.substring(0, 50)}${commentText.length > 50 ? '...' : ''}"`
              }),
            });

            // Update notification count
            loadNotificationCount();
          }
        } catch (error) {
          console.error("Error adding comment:", error);
          alert("Failed to add comment. Please try again.");
        }
      });
    });

    // Share buttons
    document.querySelectorAll('.share-btn').forEach(btn => {
      btn.addEventListener('click', function () {
        const postId = this.getAttribute('data-post-id');
        const postDiv = this.closest('.post');
        const postContent = postDiv.querySelector('.post-content').textContent;
        const postAuthor = postDiv.querySelector('.post-header strong').textContent;
        
        // Create shareable text
        const shareText = `Check out this post by ${postAuthor} on StreetSupply:\n\n"${postContent.substring(0, 100)}${postContent.length > 100 ? '...' : ''}"\n\n#StreetSupply`;
        
        // Try to use Web Share API if available
        if (navigator.share) {
          navigator.share({
            title: 'StreetSupply Post',
            text: shareText,
            url: window.location.href
          });
        } else {
          // Fallback: copy to clipboard
          navigator.clipboard.writeText(shareText).then(() => {
            alert('Post content copied to clipboard!');
          }).catch(() => {
            // Final fallback: show in alert
            alert('Share this post:\n\n' + shareText);
          });
        }
      });
    });
  }

  // Suggestions
  async function loadSuggestions() {
    const res = await fetch('http://localhost:3000/getSuggestions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userType })
    });
    const users = await res.json();
    const container = document.querySelector('.profile-suggestions');
    container.innerHTML = '';

    users.forEach(u => {
      const div = document.createElement('div');
      div.className = 'suggested-profile';
      div.innerHTML = `
        <h4>${u.fullName}</h4>
        <p>${u.address}(${u.phone})</p>
        <button class="connect-btn" onclick="connectWithUser('${u.email}')">Connect</button>
      `;
      container.appendChild(div);
    });
  }

  // Global function for connecting with users
  window.connectWithUser = async function(userEmail) {
    const sender = sessionStorage.getItem("email");
    
    try {
      await fetch("http://localhost:3000/sendNotification", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sender,
          receiver: userEmail,
          type: "connection",
          message: `${sender} wants to connect with you on StreetSupply`
        }),
      });
      
      alert("Connection request sent!");
      loadNotificationCount();
    } catch (error) {
      console.error("Error sending connection request:", error);
      alert("Failed to send connection request. Please try again.");
    }
  };

  loadSuggestions();
});
