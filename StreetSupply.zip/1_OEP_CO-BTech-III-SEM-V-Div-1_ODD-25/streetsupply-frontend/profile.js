document.addEventListener("DOMContentLoaded", async () => {
  const email = sessionStorage.getItem("email");
  if (!email) return alert("User not logged in");

  const res = await fetch(`http://localhost:3000/getUser/${email}`);
  const user = await res.json();

  // Display user data
  document.getElementById("fullNameText").textContent = user.fullName;
  document.getElementById("phoneText").textContent = user.phone;
  document.getElementById("emailText").textContent = user.email;
  document.getElementById("addressText").textContent = user.address;
  document.getElementById("pincodeText").textContent = user.pincode;
  document.getElementById("roleText").textContent = user.userType;
  document.getElementById("sellText").textContent = user.whatTheySell || "-";
  document.getElementById("needText").textContent = user.ingredientsNeeded || "-";

  if (user.profilePic) {
    document.getElementById("profilePic").src = `http://localhost:3000/${user.profilePic}`;
  }

  // Store into input fields
  document.getElementById("fullNameInput").value = user.fullName;
  document.getElementById("phoneInput").value = user.phone;
  document.getElementById("emailInput").value = user.email;
  document.getElementById("addressInput").value = user.address;
  document.getElementById("pincodeInput").value = user.pincode;
  document.getElementById("roleInput").value = user.userType;
  document.getElementById("sellInput").value = user.whatTheySell || "";
  document.getElementById("needInput").value = user.ingredientsNeeded || "";

  // Show/Hide Fields
  const toggleEditMode = (isEdit) => {
    document.querySelectorAll(".text").forEach(el => el.classList.toggle("hidden", isEdit));
    document.querySelectorAll(".input").forEach(el => el.classList.toggle("hidden", !isEdit));
    document.getElementById("editBtn").classList.toggle("hidden", isEdit);
    document.getElementById("saveBtn").classList.toggle("hidden", !isEdit);
    document.getElementById("needField").classList.toggle("hidden", !isEdit);
  };

  document.getElementById("editBtn").addEventListener("click", () => {
    toggleEditMode(true);
  });

  document.getElementById("saveBtn").addEventListener("click", async () => {
    const formData = new FormData();
    formData.append("email", email);
    formData.append("fullName", document.getElementById("fullNameInput").value);
    formData.append("phone", document.getElementById("phoneInput").value);
    formData.append("address", document.getElementById("addressInput").value);
    formData.append("pincode", document.getElementById("pincodeInput").value);
    formData.append("userType", document.getElementById("roleInput").value);
    formData.append("whatTheySell", document.getElementById("sellInput").value);
    formData.append("ingredientsNeeded", document.getElementById("needInput").value);

    const res = await fetch("http://localhost:3000/updateProfile", {
      method: "POST",
      body: formData,
    });

    const result = await res.json();
    alert(result.message);
    location.reload();
  });

  // Upload profile pic
const picUpload = document.getElementById("picUpload");
const uploadBtn = document.getElementById("uploadBtn");

uploadBtn.addEventListener("click", () => {
  picUpload.click(); // trigger file input
});

// When file is selected, upload automatically
picUpload.addEventListener("change", async () => {
  const file = picUpload.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append("email", email);
  formData.append("profilePic", file);

  const res = await fetch("http://localhost:3000/updateProfile", {
    method: "POST",
    body: formData,
  });

  const result = await res.json();
  alert(result.message);
  location.reload();
});

// Logout functionality
document.getElementById("logoutBtn").addEventListener("click", () => {
  sessionStorage.clear();
  localStorage.clear();
  alert("Logged out successfully!");
  window.location.href = "index.html";
});

});
