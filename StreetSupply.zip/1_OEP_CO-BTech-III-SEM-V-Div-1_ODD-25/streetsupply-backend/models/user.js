const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    fullName: String,
    phone: String,
    email: String,
    address: String,
    pincode: String,
    locationMap: String,
    password: String,
    userType: String, // 'buyer' or 'seller'
});

module.exports = mongoose.model('User', userSchema);
