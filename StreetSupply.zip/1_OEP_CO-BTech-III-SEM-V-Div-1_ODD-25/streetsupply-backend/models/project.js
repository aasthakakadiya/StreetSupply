const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {type:String, required:true},
  description: String,
  category: String,
  price: {type:Number, required:true},
  image: String, // store URL or path
  sellerEmail: String, // who added the product (seller)
  createdAt: {type:Date, default:Date.now},
  // optionally store sellerId if you have user ids
});

module.exports = mongoose.model('Product', productSchema);
