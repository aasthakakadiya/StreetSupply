const express = require("express");
const router = express.Router();
const Notification = require("../models/notification");

router.post("/sendNotification", async (req, res) => {
  const { sender, receiver, type, postId } = req.body;

  let message = "";
  if (type === "like") message = `${sender} liked your post.`;
  else if (type === "comment") message = `${sender} commented on your post.`;

  try {
    const notification = new Notification({
      sender,
      receiver,
      type,
      postId,
      message,
    });

    await notification.save();
    res.json({ success: true, message: "Notification saved" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error saving notification" });
  }
});

router.post("/getNotifications", async (req, res) => {
  const { email } = req.body;
  const notifications = await Notification.find({ receiver: email }).sort({ createdAt: -1 });
  res.json(notifications);
});

router.post("/markNotificationRead", async (req, res) => {
  const { id } = req.body;
  await Notification.findByIdAndUpdate(id, { read: true });
  res.json({ success: true });
});


module.exports = router;
