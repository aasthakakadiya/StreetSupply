const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();
const PORT = 3000;
const multer = require('multer');
const path = require('path');
app.use("/uploads", express.static("uploads"));
app.use(express.static("streetsupply-frontend"));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) =>
    cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/streetsupply", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));
db.once("open", () => console.log("Connected to MongoDB"));

// Check MongoDB connection status
app.get("/status", (req, res) => {
  const dbStatus = mongoose.connection.readyState;
  let statusMessage = "";

  switch (dbStatus) {
    case 0: statusMessage = "disconnected"; break;
    case 1: statusMessage = "connected"; break;
    case 2: statusMessage = "connecting"; break;
    case 3: statusMessage = "disconnecting"; break;
    default: statusMessage = "unknown"; break;
  }

  res.json({
    server: "running",
    database: statusMessage,
    timestamp: new Date().toISOString()
  });
});

// ===== User Schema =====
const userSchema = new mongoose.Schema({
  userType: String,
  fullName: String,
  phone: String,
  email: String,
  address: String,
  pincode: String,
  location: String,
  password: String,
  whatTheySell: String,
  ingredientsNeeded: String,
  profilePic: String, // image path
  sellItems: [String], // Array of items seller sells
  needItems: [String],  // Array of items buyer needs

  // New fields for cart & orders
  cart: [
    {
      productId: String,
      productName: String,
      price: Number,
      quantity: Number,
      sellerEmail: String
    }
  ],
  orders: [{ type: mongoose.Schema.Types.ObjectId, ref: "Order" }]
});
const User = mongoose.model("User", userSchema);


// ===== Product Schema =====
const productSchema = new mongoose.Schema({
  sellerEmail: String,
  productName: String,
  category: String,
  price: Number,
  description: String,
  createdAt: { type: Date, default: Date.now }
});
const Product = mongoose.model("Product", productSchema);

// ===== Post Schema =====
const postSchema = new mongoose.Schema({
  userName: String,
  userEmail: String,         // Who created the post
  content: String,           // Text content
  imageUrl: String,          // Optional image
  createdAt: { type: Date, default: Date.now },
});
const Post = mongoose.model("Post", postSchema);

// ===== Notification Schema =====
const notificationSchema = new mongoose.Schema({
  sender: String,     // Komal's email or name
  receiver: String,   // Mahi's email
  type: String,       // "like", "comment"
  postId: String,
  message: String,
  createdAt: {
    type: Date,
    default: Date.now,
  },
  read: {
    type: Boolean,
    default: false,
  },
});
const Notification = mongoose.model('Notification', notificationSchema);

// ===== Order Schema =====
const orderSchema = new mongoose.Schema({
  buyerEmail: String,
  items: [
    {
      productId: String,
      productName: String,
      price: Number,
      quantity: { type: Number, default: 1 },
      sellerEmail: String
    }
  ],
  totalAmount: Number,
  orderDate: Date,
  status: String
});

const Order = mongoose.model("Order", orderSchema);


// ===== Register =====
app.post("/register", async (req, res) => {
  const { userType, fullName, phone, email, address, pincode, location, password } = req.body;
  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.json({ success: false, message: "Email already exists." });

    const newUser = new User({ userType, fullName, phone, email, address, pincode, location, password });
    await newUser.save();
    res.json({ success: true, message: "User registered successfully." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error." });
  }
});

// ===== Login =====
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user || user.password !== password) {
      return res.json({ success: false, message: "Invalid credentials." });
    }

    res.json({
      success: true,
      message: "Login successful.",
      user: {
        fullName: user.fullName,
        phone: user.phone,
        email: user.email,
        address: user.address,
        userType: user.userType,
        whatTheySell: user.whatTheySell,
        ingredientsNeeded: user.ingredientsNeeded,
        sellItems: user.sellItems,
        needItems: user.needItems
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error." });
  }
});

// ===== Get Logged-in User Details =====
app.post("/getUser", async (req, res) => {
  const { email } = req.body;
  try {
    console.log("=== POST GET USER ===");
    console.log("Requested email:", email);

    const user = await User.findOne({ email });
    console.log("User found:", user ? "Yes" : "No");

    if (user) {
      console.log("User details:", {
        fullName: user.fullName,
        email: user.email,
        userType: user.userType,
        whatTheySell: user.whatTheySell,
        ingredientsNeeded: user.ingredientsNeeded
      });
      res.json({
        fullName: user.fullName,
        phone: user.phone,
        email: user.email,
        address: user.address,
        userType: user.userType,
        whatTheySell: user.whatTheySell,
        ingredientsNeeded: user.ingredientsNeeded,
        sellItems: user.sellItems || [],
        needItems: user.needItems || []
      });
    } else {
      console.log("User not found in database");
      res.status(404).json({ message: "User not found" });
    }
  } catch (err) {
    console.error("Error in POST getUser:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ===== Get User by Email (GET) =====
app.get("/getUser/:email", async (req, res) => {
  try {
    console.log("=== GET USER BY EMAIL ===");
    console.log("Requested email:", req.params.email);

    const user = await User.findOne({ email: req.params.email });
    console.log("User found:", user ? "Yes" : "No");

    if (user) {
      console.log("User details:", {
        fullName: user.fullName,
        email: user.email,
        userType: user.userType,
        whatTheySell: user.whatTheySell,
        ingredientsNeeded: user.ingredientsNeeded
      });
      res.json({
        fullName: user.fullName,
        phone: user.phone,
        email: user.email,
        address: user.address,
        userType: user.userType,
        whatTheySell: user.whatTheySell,
        ingredientsNeeded: user.ingredientsNeeded,
        sellItems: user.sellItems || [],
        needItems: user.needItems || []
      });
    } else {
      console.log("User not found in database");
      res.status(404).json({ message: "User not found" });
    }
  } catch (err) {
    console.error("Error in getUser/:email:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ===== Create Post =====
app.post("/createPost", async (req, res) => {
  const { userEmail, content, imageUrl } = req.body;
  try {
    const post = new Post({ userEmail, content, imageUrl });
    await post.save();
    res.json({ success: true, message: "Post created." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Post creation failed." });
  }
});

// ===== Get All Posts =====
app.get("/getPosts", async (req, res) => {
  try {
    const posts = await Post.find({}).sort({ createdAt: -1 });

    const enrichedPosts = await Promise.all(
      posts.map(async (post) => {
        const user = await User.findOne({ email: post.userEmail });
        return {
          ...post._doc,
          userName: user ? user.fullName : "Unknown User",
          userEmail: post.userEmail || "Unknown Email",
        };
      })
    );

    res.json(enrichedPosts);
  } catch (err) {
    res.status(500).json({ message: "Error fetching posts" });
  }
});

// ===== Update User Profile =====    
app.post("/updateProfile", upload.single("profilePic"), async (req, res) => {
  const { email, fullName, phone, address, pincode, userType, whatTheySell, ingredientsNeeded } = req.body;
  const updateData = { fullName, phone, address, pincode, userType, whatTheySell, ingredientsNeeded };

  if (req.file) {
    updateData.profilePic = "uploads/" + req.file.filename;
  }

  try {
    await User.findOneAndUpdate({ email }, updateData);
    res.json({ success: true, message: "Profile updated successfully." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Profile update failed." });
  }
});

// ===== Get Suggestions: Opposite User Type =====
app.post("/getSuggestions", async (req, res) => {
  const { userType } = req.body;
  try {
    const oppositeType = userType === "buyer" ? "seller" : "buyer";
    const suggestions = await User.find({ userType: oppositeType }).limit(5);
    res.json(suggestions);
  } catch (err) {
    res.status(500).json({ message: "Error fetching suggestions" });
  }
});

// ===== Product Endpoints =====

// Add a new product
app.post("/addProduct", async (req, res) => {
  const { sellerEmail, productName, category, price, description } = req.body;

  console.log("Received product data:", { sellerEmail, productName, category, price, description });

  try {
    // Validate required fields
    if (!sellerEmail || !productName || !category || !price || !description) {
      console.log("Validation failed - missing fields:", { sellerEmail, productName, category, price, description });
      return res.status(400).json({
        success: false,
        message: "All fields are required",
        received: { sellerEmail, productName, category, price, description }
      });
    }

    // Validate price is a number
    if (isNaN(price) || price <= 0) {
      return res.status(400).json({
        success: false,
        message: "Price must be a positive number"
      });
    }

    const product = new Product({
      sellerEmail,
      productName: productName.trim(),
      category: category.trim(),
      price: parseFloat(price),
      description: description.trim()
    });

    console.log("Saving product:", product);
    await product.save();

    console.log("Product saved successfully:", product._id);
    res.json({ success: true, message: "Product added successfully!", productId: product._id });
  } catch (err) {
    console.error("Error adding product:", err);
    res.status(500).json({
      success: false,
      message: "Failed to add product",
      error: err.message,
      details: err.toString()
    });
  }
});

// Get all products
app.get("/getProducts", async (req, res) => {
  try {
    console.log("Fetching all products...");
    const products = await Product.find({}).sort({ createdAt: -1 });
    console.log("Found products:", products.length, products);
    res.json(products);
  } catch (err) {
    console.error("Error fetching products:", err);
    res.status(500).json({ success: false, message: "Failed to fetch products", error: err.message });
  }
});

// Get products by seller
app.get("/getSellerProducts", async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(400).json({ success: false, message: "Email parameter is required" });
    }
    const products = await Product.find({ sellerEmail: email }).sort({ createdAt: -1 });
    res.json(products);
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch seller products", error: err.message });
  }
});

// Get all products (for buyer)
app.get("/getAllSellerProducts", async (req, res) => {
  try {
    const products = await Product.find({}).sort({ createdAt: -1 });
    res.json(products);
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch all products", error: err.message });
  }
});

// Delete a product
app.delete("/deleteProduct/:productId", async (req, res) => {
  try {
    const { productId } = req.params;
    const product = await Product.findByIdAndDelete(productId);

    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }

    res.json({ success: true, message: "Product deleted successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to delete product", error: err.message });
  }
});

// Update a product
app.put("/updateProduct/:productId", async (req, res) => {
  try {
    const { productId } = req.params;
    const { productName, category, price, description } = req.body;

    const product = await Product.findByIdAndUpdate(
      productId,
      { productName, category, price, description },
      { new: true }
    );

    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }

    res.json({ success: true, message: "Product updated successfully", product });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to update product", error: err.message });
  }
});

// ===== Notification Endpoints =====

// Get notifications for a user
app.post("/getNotifications", async (req, res) => {
  try {
    const { email } = req.body;
    const notifications = await Notification.find({ receiver: email }).sort({ createdAt: -1 });
    res.json(notifications);
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch notifications", error: err.message });
  }
});

// Send notification
app.post("/sendNotification", async (req, res) => {
  try {
    const { sender, receiver, type, postId } = req.body;

    let message = "";
    if (type === "like") message = `${sender} liked your post.`;
    else if (type === "comment") message = `${sender} commented on your post.`;

    const notification = new Notification({
      sender,
      receiver,
      type,
      postId,
      message,
    });

    await notification.save();
    res.json({ success: true, message: "Notification sent" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to send notification", error: err.message });
  }
});

// ===== Additional Endpoints for Order Page =====

// Get users by type
app.get("/getUsers", async (req, res) => {
  try {
    const users = await User.find({}).select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch users", error: err.message });
  }
});

// Search products
app.get("/searchProducts", async (req, res) => {
  try {
    const { query, category } = req.query;
    let searchQuery = {};

    if (query) {
      searchQuery.$or = [
        { productName: { $regex: query, $options: 'i' } },
        { description: { $regex: query, $options: 'i' } },
        { category: { $regex: query, $options: 'i' } }
      ];
    }

    if (category) {
      searchQuery.category = { $regex: category, $options: 'i' };
    }

    const products = await Product.find(searchQuery).sort({ createdAt: -1 });
    res.json(products);
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to search products", error: err.message });
  }
});

// Get product categories
app.get("/getCategories", async (req, res) => {
  try {
    const categories = await Product.distinct("category");
    res.json(categories);
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch categories", error: err.message });
  }
});

// ===== Debug Endpoints =====

// Check if server is running
app.get("/", (req, res) => {
  res.json({ message: "StreetSupply Server is running!", status: "OK" });
});

// Get all users (for debugging)
app.get("/debug/users", async (req, res) => {
  try {
    const users = await User.find({}).select('-password');
    res.json({ count: users.length, users });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch users", error: err.message });
  }
});

// Get all products (for debugging)
app.get("/debug/products", async (req, res) => {
  try {
    const products = await Product.find({});
    res.json({ count: products.length, products });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch products", error: err.message });
  }
});

// Test endpoint for Product model
app.get("/test/product", async (req, res) => {
  try {
    // Test creating a product
    const testProduct = new Product({
      sellerEmail: "test@test.com",
      productName: "Test Product",
      category: "Test Category",
      price: 100,
      description: "Test Description"
    });

    await testProduct.save();
    await Product.findByIdAndDelete(testProduct._id); // Clean up

    res.json({
      success: true,
      message: "Product model is working correctly",
      testProduct: testProduct
    });
  } catch (err) {
    console.error("Product model test failed:", err);
    res.status(500).json({
      success: false,
      message: "Product model test failed",
      error: err.message
    });
  }
});

// Debug endpoint to check if user exists
app.get("/debug/user/:email", async (req, res) => {
  try {
    console.log("=== DEBUG USER CHECK ===");
    console.log("Checking for user:", req.params.email);

    const user = await User.findOne({ email: req.params.email });

    if (user) {
      res.json({
        exists: true,
        user: {
          fullName: user.fullName,
          email: user.email,
          userType: user.userType,
          whatTheySell: user.whatTheySell,
          ingredientsNeeded: user.ingredientsNeeded,
          sellItems: user.sellItems,
          needItems: user.needItems
        }
      });
    } else {
      res.json({
        exists: false,
        message: "User not found in database"
      });
    }
  } catch (err) {
    console.error("Error in debug user check:", err);
    res.status(500).json({ error: err.message });
  }
});

// ===== Order Endpoints =====

// Create a new order
app.post("/createOrder", async (req, res) => {
  try {
    const { buyerEmail, items, total, paymentMethod } = req.body;

    // Validate required fields
    if (!buyerEmail || !items || !total || !paymentMethod) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
        received: { buyerEmail, items, total, paymentMethod }
      });
    }

    // ✅ Validate payment method (add this block here)
    if (!["COD", "Online"].includes(paymentMethod)) {
      return res.status(400).json({
        success: false,
        message: "Invalid payment method. Must be 'COD' or 'Online'."
      });
    }

    // Validate items array
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Items must be a non-empty array"
      });
    }

    // Validate total is a positive number
    if (isNaN(total) || total <= 0) {
      return res.status(400).json({
        success: false,
        message: "Total must be a positive number"
      });
    }

    const order = new Order({
      buyerEmail,
      items,
      totalAmount: total,   // use total value from req.body
      orderDate: new Date(),
      timestamp: new Date(),
      status: "Pending"
    });
    await order.save();

    await User.updateOne({ email: buyerEmail }, { $set: { cart: [] } });
    res.json({ success: true, message: "Order placed successfully", orderId: order._id });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error creating order", error: err.message });
  }
});



// Get orders for a user
app.get("/getOrders/:email", async (req, res) => {
  try {
    const { email } = req.params;
    if (!email) {
      return res.status(400).json({ success: false, message: "Email parameter is required" });
    }

    const orders = await Order.find({ buyerEmail: email }).sort({ timestamp: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch orders", error: err.message });
  }
});

// Get all orders (for admin/debugging)
app.get("/getAllOrders", async (req, res) => {
  try {
    const orders = await Order.find({}).sort({ timestamp: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch orders", error: err.message });
  }
});

// Get orders for a seller (orders containing this seller's email)
app.get("/getOrdersForSeller", async (req, res) => {
  try {
    const { sellerEmail } = req.query;
    if (!sellerEmail) return res.status(400).json({ success: false, message: "sellerEmail required" });

    const orders = await Order.find({ "items.sellerEmail": sellerEmail }).sort({ timestamp: -1 }).lean();
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch seller orders", error: err.message });
  }
});


// ===== Filtered Seller Products for Order Page =====
app.post("/getFilteredProducts", async (req, res) => {
  try {
    const { category } = req.body;
    const filter = {};
    if (category && category.trim() !== "") {
      filter.category = { $regex: category, $options: "i" };
    }
    // Only products added by sellers — we assume sellers add products, so return all matching
    const products = await Product.find(filter).sort({ createdAt: -1 }).lean();
    return res.json({ success: true, products });
  } catch (err) {
    console.error("getFilteredProducts error:", err);
    res.status(500).json({ success: false, message: "Error fetching filtered products", error: err.message });
  }
});

// ===== Add item to cart =====
app.post("/addToCart", async (req, res) => {
  try {
    const { email, productId, quantity = 1 } = req.body;
    if (!email || !productId) return res.status(400).json({ success: false, message: "Email and productId required" });

    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    const product = await Product.findById(productId).lean();
    if (!product) return res.status(404).json({ success: false, message: "Product not found" });

    // If product already in cart, update quantity
    const idx = user.cart.findIndex(i => i.productId === productId);
    if (idx >= 0) {
      user.cart[idx].quantity = Math.max(1, user.cart[idx].quantity + Number(quantity));
    } else {
      user.cart.push({
        productId: product._id.toString(),
        productName: product.productName,
        price: product.price,
        quantity: Number(quantity),
        sellerEmail: product.sellerEmail || ""
      });
    }

    await user.save();
    res.json({ success: true, message: "Added to cart", cart: user.cart });
  } catch (err) {
    console.error("addToCart error:", err);
    res.status(500).json({ success: false, message: "Failed to add to cart", error: err.message });
  }
});

// ===== Get cart for a user =====
app.get("/getCart", async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: "Email required" });
    const user = await User.findOne({ email }).lean();
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    res.json({ success: true, cart: user.cart || [] });
  } catch (err) {
    console.error("getCart error:", err);
    res.status(500).json({ success: false, message: "Failed to fetch cart", error: err.message });
  }
});

// ===== Remove item from cart =====
app.post("/removeFromCart", async (req, res) => {
  try {
    const { email, productId } = req.body;
    if (!email || !productId) return res.status(400).json({ success: false, message: "Email and productId required" });

    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    user.cart = user.cart.filter(i => i.productId !== productId);
    await user.save();
    res.json({ success: true, message: "Removed from cart", cart: user.cart });
  } catch (err) {
    console.error("removeFromCart error:", err);
    res.status(500).json({ success: false, message: "Failed to remove from cart", error: err.message });
  }
});



// ===== Start Server =====
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Debug endpoints available:`);
  console.log(`  - GET / (server status)`);
  console.log(`  - GET /debug/users (all users)`);
  console.log(`  - GET /debug/products (all products)`);
});
